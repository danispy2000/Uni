#!/bin/bash
ADDRESS=$1
PORT=$2
DURATION=$3
INTERVAL=$4
ssh ${ADDRESS} "docker pull shwartszko/315185918_322659749 && docker run -d -p ${PORT}:${PORT} --name 315185918_322659749 docker.io/shwartszko/315185918_322659749 iperf3 -s -p ${PORT}"
iperf3 -c ${ADDRESS} -i$INTERVAL -t$DURATION -p ${PORT}
ssh ${ADDRESS} "docker stop 315185918_322659749 && docker rm 315185918_322659749"


#!/bin/bash
echo "- = Starting = -"
echo "- = Creating resources = -"
kubectl apply -f hw2_resources_ver1.yaml --record=true
IP=$(kubectl get services | grep nginx-ver1-srv | awk '{print $3}')
echo "- = The IP Address of my service is: $IP = -"
end=$((SECONDS+240))
while [ ${SECONDS} -lt ${end} ]
do
	#echo "$IP"
	wget $IP:80 -q -O-
done

echo "- = Updating application = -"
sleep 30

kubectl apply -f hw2_resources_ver2.yaml --record=true
kubectl rollout status deployment nginx-ver1-dep
#echo "$IP"

wget $IP:80 -q -O-
echo "- = Rolling back = -"
sleep 15

kubectl rollout undo deployment nginx-ver1-dep
kubectl rollout status deployment nginx-ver1-dep

sleep 30

wget $IP:80 -q -O-

echo "- = Cleaning up = -"
kubectl delete -f hw2_resources_ver1.yaml

echo "- = Great Success! = -"


package wordcount;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

public class MapSort extends Mapper<LongWritable, Text, Text, Text> {

    @Override
    public void map(LongWritable key, Text events, Context context)
            throws IOException, InterruptedException {

        String line = events.toString();
        String[] input = line.split("\t");
        String[] words = input[1].split(", ");
        String[] temp;
        String out = "";
        for (int i=0; i< words.length; i++) {
            temp = words[i].split(",");

            if(i == words.length - 1) {
                out += temp[1]+","+ temp[2].charAt(0);
            }
            else{
                out += temp[1]+","+temp[2];
            }

            out += " ";
        }
        context.write(new Text(input[0]), new Text(out));
    }
}

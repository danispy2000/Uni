package wordcount;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.util.*;

public class Reduce extends Reducer<Text, Text, Text, Text> {

    @Override
    public void reduce(Text sid, Iterable<Text> events, Context context)
            throws IOException, InterruptedException {

        Set<String> s1 = new TreeSet<>();


        for(Text event : events) {
           s1.add(event.toString());
        }

        context.write(new Text(sid), new Text(s1.toString()));
    }
}

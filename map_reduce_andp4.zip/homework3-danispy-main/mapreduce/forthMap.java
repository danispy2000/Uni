package wordcount;

import com.sun.org.apache.xml.internal.utils.StringToIntTable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

public class forthMap extends Mapper<LongWritable, Text, LongWritable, Text> {

    @Override
    public void map(LongWritable key, Text events, Context context)
            throws IOException, InterruptedException {

        String line = events.toString();
        String[] Final = line.split("\t");
        context.write(new LongWritable(-1*Long.parseLong(Final[1])), new Text(Final[0]));


    }
}

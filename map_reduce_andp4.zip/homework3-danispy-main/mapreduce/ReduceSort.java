package wordcount;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.util.Arrays;

public class ReduceSort extends Reducer<Text, Text, Text, Text> {

    @Override
    public void reduce(Text sid, Iterable<Text> values, Context context)
            throws IOException, InterruptedException {

        String temp = "";
        for (Text val : values) {
            temp+=val.toString();
        }
        String[] splitVals = temp.split(" ");
        String triplets = "";
        int len = splitVals.length;

        if(splitVals.length == 1)
        {
            triplets = splitVals[0].substring(0,splitVals[0].length()-1);
            triplets += '0';
            String newTriplets = " " + triplets + " " + triplets;

            context.write(new Text(sid), new Text(newTriplets));
        }
        else if(splitVals.length == 2)
        {
            triplets = splitVals[1].substring(0,splitVals[1].length()-1);
            triplets += '0';
            String newTriplets = splitVals[0] + " " + triplets + " " + triplets;
            context.write(new Text(sid), new Text(newTriplets));
        }
        else
        {
            for (int i=0;i < splitVals.length-2;i++)
            {
                String[] threeWay = Arrays.copyOfRange(splitVals,i,i+3);
                triplets = threeWay[0] + " " + threeWay[1] + " " + threeWay[2];
                context.write(new Text(sid), new Text(triplets));
            }
        }
    }
}

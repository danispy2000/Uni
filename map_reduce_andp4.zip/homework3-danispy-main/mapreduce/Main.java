package wordcount;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import java.util.Random;

public class Main extends Configured implements Tool {

    // ------------- DRIVER ------------
    @Override
    public int run(String[] args) throws Exception {
        Path tempDir = new Path("data/temp-" + Integer.toString(new Random().nextInt(Integer.MAX_VALUE)));
        Path tempDir1 = new Path("data/temp-101");
        Path tempDir2 = new Path("data/temp-102");
        Configuration conf = getConf();
        FileSystem.get(conf).delete(new Path("data/output"), true);

        try {
            // ----------- FIRST JOB -----------
            System.out.println("-------FIRST JOB-------");
            Job stage1 = Job.getInstance(conf);
            stage1.setJobName("stage1");
            stage1.setJarByClass(Main.class);

            stage1.setMapOutputValueClass(Text.class);
            stage1.setOutputKeyClass(Text.class);
            stage1.setOutputValueClass(Text.class);

            stage1.setMapperClass(Map.class);
            stage1.setReducerClass(Reduce.class);

            Path inputFilePath = new Path("data/input/");
            Path outputFilePath = tempDir;

            FileInputFormat.addInputPath(stage1, inputFilePath);
            FileOutputFormat.setOutputPath(stage1, outputFilePath);

            if (!stage1.waitForCompletion(true)) {
                return 1;
            }

            // ----------- SECOND JOB -----------
            System.out.println("-------SECOND JOB-------");
            conf = new Configuration();
            Job stage2 = Job.getInstance(conf);
            stage2.setJobName("stage2");

            Path outputFilePath1 = tempDir1;
            stage2.setJarByClass(Main.class);
            FileInputFormat.setInputPaths(stage2, tempDir);
            FileOutputFormat.setOutputPath(stage2,outputFilePath1);

            stage2.setMapOutputValueClass(Text.class);
            stage2.setOutputKeyClass(Text.class);
            stage2.setOutputValueClass(Text.class);

            stage2.setMapperClass(MapSort.class);
            stage2.setReducerClass(ReduceSort.class);

            if (!stage2.waitForCompletion(true)) {
                return 1;
            }


            // ----------- THIRD JOB -----------
            System.out.println("-------THIRD JOB-------");
            conf = new Configuration();
            Job stage3 = Job.getInstance(conf);
            stage3.setJobName("stage3");

            stage3.setJarByClass(Main.class);
            FileInputFormat.setInputPaths(stage3, outputFilePath1);
            FileOutputFormat.setOutputPath(stage3, tempDir2);

            stage3.setMapOutputValueClass(IntWritable.class);
            stage3.setOutputKeyClass(Text.class);
            stage3.setOutputValueClass(LongWritable.class);

            stage3.setMapperClass(thirdMap.class);
            stage3.setReducerClass(thirdReduce.class);

            if (!stage3.waitForCompletion(true)) {
                return 1;
            }
            // ----------- FORTH JOB -----------
            System.out.println("-------FORTH JOB-------");
            conf = new Configuration();
            Job stage4 = Job.getInstance(conf);
            stage4.setJobName("stage4");

            stage4.setJarByClass(Main.class);
            FileInputFormat.setInputPaths(stage4, tempDir2);
            FileOutputFormat.setOutputPath(stage4, new Path("data/output"));

            stage4.setMapOutputValueClass(Text.class);
            stage4.setMapOutputKeyClass(LongWritable.class);
            stage4.setOutputKeyClass(Text.class);
            stage4.setOutputValueClass(LongWritable.class);

            stage4.setMapperClass(forthMap.class);
            stage4.setReducerClass(forthReduce.class);

            return stage4.waitForCompletion(true) ? 0 : 1;
        } finally {
            FileSystem.get(conf).delete(tempDir, true);
            FileSystem.get(conf).delete(tempDir1, true);
            FileSystem.get(conf).delete(tempDir2, true);
        }
    }

    public static void main(String[] args) throws Exception {
        int exitCode = ToolRunner.run(new Main(), args);
        System.exit(exitCode);
    }
}
